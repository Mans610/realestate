import 'package:flutter/cupertino.dart';

class AppColor{
   static const  themecolor = Color(0XFF42145d);
}