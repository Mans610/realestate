import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:real_estate/Constant/theme.dart';
import 'package:real_estate/Screens/LoginwithMobile.dart';

class VerifyOtp extends StatefulWidget {
  const VerifyOtp({Key? key}) : super(key: key);

  @override
  State<VerifyOtp> createState() => _VerifyOtpState();
}

class _VerifyOtpState extends State<VerifyOtp> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: 50.h,
              ),
              InkWell(
                onTap: () {
                  Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(
                        builder: (context) => LoginwithMobile(),
                      ),
                          (route) => false);
                },
                child: Icon(
                  Icons.arrow_back_sharp,
                  size: 30,
                ),
              ),

              Container(
                  width: double.infinity,
                  child: Image.asset('assets/images/verifyotp.png')),

              SizedBox(
                height: 20.h,
              ),
              Text("Verify OTP",style: TextStyle(
                color: Colors.black,fontWeight: FontWeight.w600,fontSize: 25
              ),),
              SizedBox(
                height: 10.h,
              ),
              Row(
                children: [
                  Expanded(
                    child: Text(
                      "An OTP has been sent to your mobile\nnumber +91 9857 489 635 ",
                      style: TextStyle(
                          color: Colors.black,
                          fontSize: 16,
                          fontWeight: FontWeight.w300),
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 20.h,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      height: 50.h,
                      width: 60.w,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(5),
                        border: Border.all(color: AppColor.themecolor)
                      ),
                      child: Center(
                        child: Text('9',style: TextStyle(
                          fontSize: 25,
                          color: Colors.black,fontWeight: FontWeight.bold
                        ),),
                      ),
                    ),
                    Container(
                      height: 50.h,
                      width: 60.w,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                          border: Border.all(color: AppColor.themecolor)
                      ),
                      child: Center(
                        child: Text('4',style: TextStyle(
                            fontSize: 25,
                            color: Colors.black,fontWeight: FontWeight.bold
                        ),),
                      ),
                    ),
                    Container(
                      height: 50.h,
                      width: 60.w,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                          border: Border.all(color: AppColor.themecolor)
                      ),
                      child: Center(
                        child: Text('0',style: TextStyle(
                            fontSize: 25,
                            color: Colors.black,fontWeight: FontWeight.bold
                        ),),
                      ),
                    ),
                    Container(
                      height: 50.h,
                      width: 60.w,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                          border: Border.all(color: AppColor.themecolor)
                      ),
                      child: Center(
                        child: Text('1',style: TextStyle(
                            fontSize: 25,
                            color: Colors.black,fontWeight: FontWeight.bold
                        ),),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 20.h,
              ),
              Container(
                height: 50.h,
                width: double.infinity,
                decoration: BoxDecoration(
                    color: AppColor.themecolor,
                    borderRadius: BorderRadius.circular(10)),
                child: Center(
                  child: Text(
                    "VERIFY",
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 17.sp,
                        fontWeight: FontWeight.w800),
                  ),
                ),
              ),
              SizedBox(
                height: 20.h,
              ),
              Center(
                child: Text("Resend OTP",style: TextStyle(
                  color: Colors.black,fontWeight: FontWeight.w400,fontSize: 15
                ),),
              )
            ],
          ),
        ),
      ),
    );
  }
}
