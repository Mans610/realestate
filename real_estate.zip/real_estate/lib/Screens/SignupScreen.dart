import 'dart:math';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:intl_phone_field/intl_phone_field.dart';

import '../Constant/theme.dart';
import 'DashboardScreen.dart';
import 'LoginScreen.dart';

class SignupScreen extends StatefulWidget {
  const SignupScreen({Key? key}) : super(key: key);

  @override
  State<SignupScreen> createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  bool buyer = false;
  bool seller = false;
  bool broker = false;
  bool ishidden = true;
  bool agree = false;
  bool update = false;
  late final bool autoValidate;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    buyer = true;
    seller = false;
    broker = false;
  }

  final _scaffoldkey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Form(
            key: _scaffoldkey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: 50.h,
                ),
                InkWell(
                  onTap: () {
                    Navigator.pushAndRemoveUntil(
                        context,
                        MaterialPageRoute(
                          builder: (context) => LoginScreen(),
                        ),
                        (route) => false);
                  },
                  child: Icon(
                    Icons.arrow_back_sharp,
                    size: 30,
                  ),
                ),
                SizedBox(
                  height: 10.h,
                ),
                Text(
                  'Register with us',
                  style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.w600,
                      fontSize: 25),
                ),
                SizedBox(
                  height: 5.h,
                ),
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        "Create an account to fulfill your dreams.",
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 16,
                            fontWeight: FontWeight.w300),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 20.h,
                ),
                Text(
                  "I want to register as:",
                  style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.w600,
                      fontSize: 16),
                ),
                SizedBox(
                  height: 5.h,
                ),
                Container(
                  height: 40.h,
                  width: double.infinity,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(width: 1, color: Colors.black)),
                  child: Row(
                    children: [
                      SizedBox(
                        width: 5,
                      ),
                      InkWell(
                        onTap: () {
                          setState(() {
                            buyer = !buyer;
                            seller = false;
                            broker = false;
                          });
                        },
                        child: Padding(
                          padding: const EdgeInsets.symmetric(vertical: 3),
                          child: Container(
                            height: 35.h,
                            width: 100.w,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                color: buyer == true
                                    ? AppColor.themecolor
                                    : Colors.white),
                            child: Center(
                              child: Text(
                                "Buyer",
                                style: TextStyle(
                                    color: buyer == true
                                        ? Colors.white
                                        : Colors.grey,
                                    fontWeight: FontWeight.w600),
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 5,
                      ),
                      InkWell(
                        onTap: () {
                          setState(() {
                            buyer = false;
                            seller = !seller;
                            broker = false;
                          });
                        },
                        child: Padding(
                          padding: const EdgeInsets.symmetric(vertical: 3),
                          child: InkWell(
                            child: Container(
                              height: 35.h,
                              width: 100.w,
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  color: seller == true
                                      ? AppColor.themecolor
                                      : Colors.white),
                              child: Center(
                                child: Text(
                                  "Seller",
                                  style: TextStyle(
                                      color: seller == true
                                          ? Colors.white
                                          : Colors.grey,
                                      fontWeight: FontWeight.w600),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 5,
                      ),
                      InkWell(
                        onTap: () {
                          setState(() {
                            buyer = false;
                            seller = false;
                            broker = !broker;
                          });
                        },
                        child: Padding(
                          padding: const EdgeInsets.symmetric(vertical: 3),
                          child: Container(
                            height: 35.h,
                            width: 100.w,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                color: broker == true
                                    ? AppColor.themecolor
                                    : Colors.white),
                            child: Center(
                              child: Text(
                                "Broker",
                                style: TextStyle(
                                    color: broker == true
                                        ? Colors.white
                                        : Colors.grey,
                                    fontWeight: FontWeight.w600),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 20.h,
                ),
                TextFormField(
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'This Field Is Required';
                    }
                  },
                  decoration: InputDecoration(
                      hintText: "Enter Name",
                      label: Text(
                        "Name",
                        style: TextStyle(color: AppColor.themecolor),
                      ),
                      focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: AppColor.themecolor),
                          borderRadius: BorderRadius.circular(10)),
                      border: OutlineInputBorder(
                          borderSide: BorderSide(color: AppColor.themecolor),
                          borderRadius: BorderRadius.circular(10))),
                ),
                SizedBox(
                  height: 15.h,
                ),
                TextFormField(
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'This Field Is Required';
                    }

                    // using regular expression
                    if (!RegExp(r'\S+@\S+\.\S+').hasMatch(value)) {
                      return "Please Enter a Valid Email Address";
                    }

                    // the email is valid
                    return null;
                  },
                  decoration: InputDecoration(
                      hintText: 'Your Email',
                      label: Text(
                        "Email",
                        style: TextStyle(color: AppColor.themecolor),
                      ),
                      focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: AppColor.themecolor),
                          borderRadius: BorderRadius.circular(10)),
                      border: OutlineInputBorder(
                          borderSide: BorderSide(color: AppColor.themecolor),
                          borderRadius: BorderRadius.circular(10))),
                ),
                SizedBox(
                  height: 15.h,
                ),
                TextFormField(
                  obscureText: ishidden,
                  validator: (value) {
                    if (value == null) {
                      return "This Field Is Required";
                    } else if (value == null || value.length < 6) {
                      return "Enter Strong Password";
                    }
                  },
                  decoration: InputDecoration(
                      hintText: "Create Password",
                      label: Text("Password",
                          style: TextStyle(color: AppColor.themecolor)),
                      suffixIcon: IconButton(
                          onPressed: () {
                            setState(() {
                              ishidden = !ishidden;
                            });
                          },
                          icon: ishidden == true
                              ? const Icon(Icons.visibility_off,
                                  size: 25, color: Color(0XFF132E81))
                              : const Icon(Icons.visibility,
                                  size: 25, color: Color(0XFF132E81))),
                      border: OutlineInputBorder(
                          borderSide: BorderSide(color: AppColor.themecolor),
                          borderRadius: BorderRadius.circular(10)),
                      focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: AppColor.themecolor),
                          borderRadius: BorderRadius.circular(10))),
                ),
                SizedBox(
                  height: 15.h,
                ),
                IntlPhoneField(
                  maxLength: 10,
                  autoValidate: true,
                  decoration: InputDecoration(
                      labelText: 'Phone Number',
                      labelStyle: TextStyle(color: AppColor.themecolor),
                      border: OutlineInputBorder(
                          borderSide: BorderSide(color: AppColor.themecolor),
                          borderRadius: BorderRadius.circular(10)),
                      focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: AppColor.themecolor),
                          borderRadius: BorderRadius.circular(10))),
                  initialCountryCode: 'IN',
                  onChanged: (phone) {
                    print(phone.completeNumber);
                  },
                ),
                SizedBox(
                  height: 15.h,
                ),
                Row(
                  children: [
                    Checkbox(
                        value: this.agree,
                        checkColor: Colors.white,
                        activeColor: AppColor.themecolor,
                        side: BorderSide(color: AppColor.themecolor),
                        focusNode: FocusNode(),
                        onChanged: (bool? value) {
                          setState(() {
                            this.agree = value!;
                          });
                        }),
                    Text.rich(TextSpan(
                        text: 'I agree to ',
                        style: TextStyle(
                            fontSize: 14, fontWeight: FontWeight.w600),
                        children: <InlineSpan>[
                          TextSpan(
                            text: 'Terms of Services ',
                            style: TextStyle(
                                decoration: TextDecoration.underline,
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                color: AppColor.themecolor),
                          ),
                          TextSpan(
                            text: 'and ',
                            style: TextStyle(
                                fontSize: 14, fontWeight: FontWeight.w600),
                          ),
                          TextSpan(
                            text: 'Privacy Policy',
                            style: TextStyle(
                                decoration: TextDecoration.underline,
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                color: AppColor.themecolor),
                          )
                        ])),
                  ],
                ),
                Row(
                  children: [
                    Checkbox(
                        value: this.update,
                        checkColor: Colors.white,
                        activeColor: AppColor.themecolor,
                        side: BorderSide(color: AppColor.themecolor),
                        onChanged: (bool? value) {
                          setState(() {
                            this.update = value!;
                          });
                        }),
                    Text.rich(TextSpan(
                        text: 'Update me via  ',
                        style: TextStyle(
                            fontSize: 14, fontWeight: FontWeight.w600),
                        children: <InlineSpan>[
                          TextSpan(
                            text: 'Whatsapp, SMS, Phone, Email ',
                            style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                color: AppColor.themecolor),
                          ),
                        ])),
                  ],
                ),
                SizedBox(
                  height: 10.h,
                ),
                InkWell(
                  onTap: (){
                    // if(_scaffoldkey.currentState!.validate()){
                    //   Fluttertoast.showToast(
                    //       msg:
                    //       "SIGNUP SUCCESSFULY",
                    //       backgroundColor: AppColor.themecolor,
                    //       textColor: Colors.white,
                    //       gravity: ToastGravity.CENTER,
                    //       timeInSecForIosWeb: 50,
                    //       toastLength: Toast.LENGTH_SHORT);
                    // }else{
                    //   Fluttertoast.showToast(
                    //       msg:
                    //       "ALL FIELD ARE REQUIRED",
                    //       backgroundColor: AppColor.themecolor,
                    //       textColor: Colors.white,
                    //       gravity: ToastGravity.CENTER,
                    //       timeInSecForIosWeb: 50,
                    //       toastLength: Toast.LENGTH_SHORT);
                    // }
                    Navigator.push(context, MaterialPageRoute(builder: (context) => DashboardScreen(),));
                  },
                  child: Container(
                    height: 50.h,
                    width: double.infinity,
                    decoration: BoxDecoration(
                        color: AppColor.themecolor,
                        borderRadius: BorderRadius.circular(10)),
                    child: Center(
                      child: Text(
                        "CREATE AN ACCOUNT",
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 17.sp,
                            fontWeight: FontWeight.w800),
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: 10.h,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      "Already a member? ",
                      style: TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                          fontWeight: FontWeight.w300),
                    ),
                    InkWell(
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => LoginScreen(),
                            ));
                      },
                      child: Text(
                        "LOGIN",
                        style: TextStyle(
                            color: AppColor.themecolor,
                            fontSize: 14,
                            fontWeight: FontWeight.w600),
                      ),
                    )
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
