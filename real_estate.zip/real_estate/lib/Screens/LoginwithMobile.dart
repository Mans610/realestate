import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl_phone_field/intl_phone_field.dart';
import 'package:real_estate/Screens/LoginScreen.dart';
import 'package:real_estate/Screens/VerifyOtp.dart';

import '../Constant/theme.dart';

class LoginwithMobile extends StatefulWidget {
  const LoginwithMobile({Key? key}) : super(key: key);

  @override
  State<LoginwithMobile> createState() => _LoginwithMobileState();
}

class _LoginwithMobileState extends State<LoginwithMobile> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: 50.h,
              ),
              InkWell(
                onTap: () {
                  Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(
                        builder: (context) => LoginScreen(),
                      ),
                      (route) => false);
                },
                child: Icon(
                  Icons.arrow_back_sharp,
                  size: 30,
                ),
              ),
              SizedBox(
                height: 50.h,
              ),
              Text(
                'Login with Mobile',
                style: TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.w600,
                    fontSize: 25),
              ),
              SizedBox(
                height: 10.h,
              ),
              Row(
                children: [
                  Expanded(
                    child: Text(
                      "Please enter our phone number to\nreceive the OTP",
                      style: TextStyle(
                          color: Colors.black,
                          fontSize: 16,
                          fontWeight: FontWeight.w300),
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 30.h,
              ),
              IntlPhoneField(
               maxLength: 10,
                decoration: InputDecoration(
                  labelText: 'Phone Number',

                  labelStyle: TextStyle(color: AppColor.themecolor),
                  border: OutlineInputBorder(
                      borderSide: BorderSide(color: AppColor.themecolor),
                      borderRadius: BorderRadius.circular(10)),
                ),
                initialCountryCode: 'IN',
                onChanged: (phone) {
                  print(phone.completeNumber);
                },
              ),
              // TextFormField(
              //   decoration: InputDecoration(
              //
              //       label: Text("Phone Number",style: TextStyle(color: AppColor.themecolor),),
              //       focusedBorder: OutlineInputBorder(
              //           borderSide: BorderSide(color: AppColor.themecolor),
              //           borderRadius: BorderRadius.circular(10)),
              //       border: OutlineInputBorder(
              //           borderSide: BorderSide(color: AppColor.themecolor),
              //           borderRadius: BorderRadius.circular(10))),
              // ),
              SizedBox(
                height: 30.h,
              ),
              InkWell(
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context) => VerifyOtp(),) );
                },
                child: Container(
                  height: 50.h,
                  width: double.infinity,
                  decoration: BoxDecoration(
                      color: AppColor.themecolor,
                      borderRadius: BorderRadius.circular(10)),
                  child: Center(
                    child: Text(
                      "GET OTP",
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 17.sp,
                          fontWeight: FontWeight.w800),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
