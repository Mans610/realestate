import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../Constant/theme.dart';
import 'LoginScreen.dart';

class ForgotPassword extends StatefulWidget {
  const ForgotPassword({Key? key}) : super(key: key);

  @override
  State<ForgotPassword> createState() => _ForgotPasswordState();
}

class _ForgotPasswordState extends State<ForgotPassword> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: 50.h,
              ),
              InkWell(
                onTap: () {
                  Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(
                        builder: (context) => LoginScreen(),
                      ),
                          (route) => false);
                },
                child: Icon(
                  Icons.arrow_back_sharp,
                  size: 30,
                ),
              ),
              SizedBox(
                height: 20.h,
              ),
              Container(
                  height: 200.h,
                  width: double.infinity,
                  child: Image.asset('assets/images/forgot_passoword.png')),
              SizedBox(
                height: 20.h,
              ),
              Text(
                'Forgot Password?',
                style: TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.w600,
                    fontSize: 25),
              ),
              SizedBox(
                height: 10.h,
              ),
              Row(
                children: [
                  Expanded(
                    child: Text(
                      "Enter an associated Email address to get verification code",
                      style: TextStyle(
                          color: Colors.black,
                          fontSize: 16,
                          fontWeight: FontWeight.w300),
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 40.h,
              ),
              TextFormField(
                decoration: InputDecoration(

                    label: Text("Your Email",style: TextStyle(color: AppColor.themecolor),),
                    focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: AppColor.themecolor),
                        borderRadius: BorderRadius.circular(10)),
                    border: OutlineInputBorder(
                        borderSide: BorderSide(color: AppColor.themecolor),
                        borderRadius: BorderRadius.circular(10))),
              ),
              SizedBox(
                height: 40.h,
              ),
              Container(
                height: 50.h,
                width: double.infinity,
                decoration: BoxDecoration(
                    color: AppColor.themecolor,
                    borderRadius: BorderRadius.circular(10)),
                child: Center(
                  child: Text(
                    "SUBMIT",
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 17.sp,
                        fontWeight: FontWeight.w800),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
