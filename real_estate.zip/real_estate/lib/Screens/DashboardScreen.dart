import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:real_estate/Constant/theme.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({Key? key}) : super(key: key);

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int pageIndex = 0;

  final pages = [
    // const Page1(),
    // const Page2(),
    // const Page3(),
    // const Page4(),
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
     body: SingleChildScrollView(
       child: Column(
         children: [
           Container(
             height: 290.h,
             width: double.infinity,
             color: AppColor.themecolor,
             child: Column(
               children: [
                 Padding(
                   padding: const EdgeInsets.only(left: 20,top: 50),
                   child: Row(
                     children: [
                       Column(
                         crossAxisAlignment: CrossAxisAlignment.start,
                         children: [

                           Text('Hello,',style: TextStyle(
                             color: Colors.grey,fontSize: 15,fontWeight: FontWeight.bold
                           ),),
                           Text('Manish',style: TextStyle(
                               color: Colors.white,fontSize: 22,fontWeight: FontWeight.bold
                           ),)
                         ],
                       ),
                       SizedBox(
                         width: 84.w,
                       ),

                       Container(
                         height: 27.h,
                         width: 140.w,
                         decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                           color: Colors.amberAccent
                         ),
                         child: Padding(
                           padding: const EdgeInsets.symmetric(horizontal: 10),
                           child: Row(
                             mainAxisAlignment: MainAxisAlignment.spaceBetween,
                             children: [
                               Text("Post Property",style: TextStyle(
                                 color: Colors.black,fontWeight: FontWeight.w700
                               ),),
                               Container(

                                 decoration: BoxDecoration(
                                   borderRadius: BorderRadius.circular(3),
                                   color: AppColor.themecolor,
                                 ),
                                 child: Padding(
                                   padding: const EdgeInsets.symmetric(horizontal: 5),
                                   child: Text("Free",style: TextStyle(
                                     color: Colors.white
                                   ),),
                                 ),
                               ),
                             ],
                           ),
                         ),
                         
                       ),
                       SizedBox(
                         width: 8.w,
                       ),
                       Icon(Icons.notifications_none_outlined,color: Colors.white,size: 25,)
                     ],
                   ),
                 ),
                 SizedBox(
                   height: 15.h,
                 ),
                 Padding(
                   padding: const EdgeInsets.symmetric(horizontal: 20),
                   child: Row(
                     children: [
                       Text("You're searching in ",style: TextStyle(
                         color: Colors.grey,fontWeight: FontWeight.w600,fontSize: 12
                       ),),
                       Text("Ahmedabad ",style: TextStyle(
                           color: Colors.amberAccent,fontWeight: FontWeight.w600,fontSize: 12
                       ),),
                       SizedBox(
                         width: 75.w,
                       ),
                       Text("Change Location ",style: TextStyle(
                           color: Colors.white,fontWeight: FontWeight.bold,fontSize: 12
                       ),),

                     ],
                   ),
                 ),
                 SizedBox(
                   height: 10.h,
                 ),
                 Padding(
                   padding: const EdgeInsets.symmetric(horizontal: 20),
                   child: Container(
                    height: 45.h,
                     decoration: BoxDecoration(

                       color: Colors.white,
                       borderRadius: BorderRadius.circular(5),
                     ),
                     child: Center(
                       child: TextField(

                         decoration: InputDecoration(
                           prefixIcon: Icon(Icons.search,size: 35,),
                           border: InputBorder.none,
                           hintText: "Search by projects,cities,locality",
                           hintStyle: TextStyle(
                              color: Colors.grey
                           )
                         ),
                       ),
                     ),
                   ),
                 ),
                 SizedBox(
                   height: 15.h,
                 ),
                 Padding(
                   padding: const EdgeInsets.symmetric(horizontal: 20),
                   child: DottedBorder(
                     color: Colors.amberAccent,//color of dotted/dash line
                      strokeWidth: 1, //thickness of dash/dots
                     dashPattern: [5,3],
                     radius: Radius.circular(10),
                     strokeCap: StrokeCap.butt,
                     //dash patterns, 10 is dash width, 6 is space width
                     child: Container(  //inner container
                         height:80.h,
                         width: double.infinity,
                       child: Column(
                         children: [
                           SizedBox(
                             height: 10.h,
                           ),
                           Padding(
                             padding: const EdgeInsets.symmetric(horizontal: 20),
                             child: Row(
                               children: [
                                 Icon(Icons.whatshot_outlined,size: 25,color: Colors.white,),
                                 SizedBox(
                                   width: 5.w,
                                 ),
                                 Text('Get Premium',style: TextStyle(
                                   color: Colors.white,fontWeight: FontWeight.w600,fontSize: 18
                                 ),),
                                 SizedBox(
                                   width: 82.w,
                                 ),
                                 Text('Join Now',style: TextStyle(
                                     color: Colors.amber,fontWeight: FontWeight.w600,fontSize: 14
                                 ),),
                                 SizedBox(
                                   width: 5.w,
                                 ),
                                 Icon(Icons.arrow_forward,color: Colors.amber,size: 17,)
                               ],
                             ),
                           ),
                           SizedBox(
                             height: 5.h,
                           ),
                           Padding(
                             padding: const EdgeInsets.symmetric(horizontal: 50),
                             child: Row(
                               children: [
                                 Text("Subscribe to Premium package for \nmore benifits",style: TextStyle(
                                   color: Colors.grey,fontSize:12
                                 ),)
                               ],
                             ),
                           )
                         ],
                       ),
                     ),
                   ),
                 )
               ],
             ),
           ),
           Padding(
             padding: const EdgeInsets.symmetric(horizontal: 20,vertical: 20),
             child: Row(
               mainAxisAlignment: MainAxisAlignment.spaceBetween,
               children: [
                 Column(
                   crossAxisAlignment: CrossAxisAlignment.start,
                   children: [
                     Text("Featured Projects",style: TextStyle(
                       color: Colors.black,
                       fontSize: 16,
                       fontWeight: FontWeight.w600
                     ),),
                     SizedBox(
                       height: 2.h,
                     ),
                     Text("Featured Projects In Ahmedabad",style: TextStyle(
                         color: Colors.grey,
                         fontSize: 14,
                         fontWeight: FontWeight.w400
                     ),)
                   ],
                 ),
                 Text("See All",style: TextStyle(
                   color: Colors.black,fontSize: 14,fontWeight: FontWeight.w800
                 ),)
               ],
             ),
           ),
           Padding(
             padding: const EdgeInsets.symmetric(horizontal: 15),
             child: Container(
               child: SingleChildScrollView(
                 scrollDirection: Axis.horizontal,
                 child: Row(
                   children: [
                     Stack(
                       children: [
                         ClipRRect(
                           borderRadius: BorderRadius.circular(10),
                           child: Image.asset(
                             'assets/images/Building/building1.jpg',
                             height: 270.0,
                             width: 200.0,
                             fit: BoxFit.fill,
                           ),
                         ),
                         Container(
                           decoration: BoxDecoration(
                             border: Border.all(width: 1,color: Colors.white),
                             borderRadius: BorderRadius.circular(5),
                             color: AppColor.themecolor,
                           ),

                           child: Padding(
                             padding: const EdgeInsets.only(left: 5,top: 5,right: 5),
                             child: Column(
                               crossAxisAlignment: CrossAxisAlignment.start,
                               children: [
                                 Text("HH Pravesh",style: TextStyle(
                                   color: Colors.white,fontWeight: FontWeight.w600,fontSize: 10
                                 ),),
                                 Text("By HH Builders",style: TextStyle(
                                     color: Colors.white,fontWeight: FontWeight.w400,fontSize: 8
                                 ),),
                                 SizedBox(
                                   height: 5.h,
                                 ),
                                 Text("₹ 35.62L - 1.25CR",style: TextStyle(
                                     color: Colors.white,fontWeight: FontWeight.w600,fontSize: 10
                                 ),),
                                 Text("2-3-4 BHK Apartments",style: TextStyle(
                                     color: Colors.white,fontWeight: FontWeight.w600,fontSize: 8
                                 ),),
                                 SizedBox(
                                   height: 5.h,
                                 ),
                                 Text("Ghatlodiya, Ahmedabad",style: TextStyle(
                                     color: Colors.white,fontWeight: FontWeight.w600,fontSize: 10
                                 ),),
                               ],
                             ),
                           ),
                         ),


                         // Container(
                         //     height:200.h,
                         //     width:200.w,
                         //     decoration: BoxDecoration(
                         //       borderRadius: BorderRadius.circular(10),
                         //       border: Border.all(width: 1)
                         //     ),
                         //     child: Image.asset('assets/images/Building/building1.jpg',fit: BoxFit.fill,)),
                       ],
                     ),
                     SizedBox(
                       width: 10.w,
                     ),
                     Stack(
                       children: [
                         ClipRRect(
                           borderRadius: BorderRadius.circular(10),
                           child: Image.asset(
                             'assets/images/Building/building2.jpg',
                             height: 270.0,
                             width: 200.0,
                             fit: BoxFit.fill,
                           ),
                         ),
                         Container(
                           decoration: BoxDecoration(
                             border: Border.all(width: 1,color: Colors.white),
                             borderRadius: BorderRadius.circular(5),
                             color: AppColor.themecolor,
                           ),

                           child: Padding(
                             padding: const EdgeInsets.only(left: 5,top: 5,right: 5),
                             child: Column(
                               crossAxisAlignment: CrossAxisAlignment.start,
                               children: [
                                 Text("Parkview 2",style: TextStyle(
                                     color: Colors.white,fontWeight: FontWeight.w600,fontSize: 10
                                 ),),
                                 Text("By Shivalik Group",style: TextStyle(
                                     color: Colors.white,fontWeight: FontWeight.w400,fontSize: 8
                                 ),),
                                 SizedBox(
                                   height: 5.h,
                                 ),
                                 Text("₹ 58 Lac",style: TextStyle(
                                     color: Colors.white,fontWeight: FontWeight.w600,fontSize: 10
                                 ),),
                                 Text("3 BHK Apartments",style: TextStyle(
                                     color: Colors.white,fontWeight: FontWeight.w600,fontSize: 8
                                 ),),
                                 SizedBox(
                                   height: 5.h,
                                 ),
                                 Text("Shola, Ahmedabad",style: TextStyle(
                                     color: Colors.white,fontWeight: FontWeight.w600,fontSize: 10
                                 ),),
                               ],
                             ),
                           ),
                         ),


                         // Container(
                         //     height:200.h,
                         //     width:200.w,
                         //     decoration: BoxDecoration(
                         //       borderRadius: BorderRadius.circular(10),
                         //       border: Border.all(width: 1)
                         //     ),
                         //     child: Image.asset('assets/images/Building/building1.jpg',fit: BoxFit.fill,)),
                       ],
                     ),
                     SizedBox(
                       width: 10.w,
                     ),
                     Stack(
                       children: [
                         ClipRRect(
                           borderRadius: BorderRadius.circular(10),
                           child: Image.asset(
                             'assets/images/Building/building3.jpg',
                             height: 270.0,
                             width: 200.0,
                             fit: BoxFit.fill,
                           ),
                         ),
                         Container(
                           decoration: BoxDecoration(
                             border: Border.all(width: 1,color: Colors.white),
                             borderRadius: BorderRadius.circular(5),
                             color: AppColor.themecolor,
                           ),

                           child: Padding(
                             padding: const EdgeInsets.only(left: 5,top: 5,right: 5),
                             child: Column(
                               crossAxisAlignment: CrossAxisAlignment.start,
                               children: [
                                 Text("Shilpa Revanta",style: TextStyle(
                                     color: Colors.white,fontWeight: FontWeight.w600,fontSize: 10
                                 ),),
                                 Text("By Shlip Group",style: TextStyle(
                                     color: Colors.white,fontWeight: FontWeight.w400,fontSize: 8
                                 ),),
                                 SizedBox(
                                   height: 5.h,
                                 ),
                                 Text("₹ 57L - 58L",style: TextStyle(
                                     color: Colors.white,fontWeight: FontWeight.w600,fontSize: 10
                                 ),),
                                 Text("3 BHK Apartments",style: TextStyle(
                                     color: Colors.white,fontWeight: FontWeight.w600,fontSize: 8
                                 ),),
                                 SizedBox(
                                   height: 5.h,
                                 ),
                                 Text("Shola, Ahmedabad",style: TextStyle(
                                     color: Colors.white,fontWeight: FontWeight.w600,fontSize: 10
                                 ),),
                               ],
                             ),
                           ),
                         ),



                       ],
                     ),

                   ],
                 ),
               ),
             ),
           ),
           SizedBox(
             height: 20.h,
           ),
           Container(
             height: 350.h,
             width: double.infinity,
             color: Colors.grey[300],
             child: Column(
               children: [
                 SizedBox(
                   height: 20.h,
                 ),
                 Padding(
                   padding: const EdgeInsets.symmetric(horizontal: 20),
                   child: Row(
                     mainAxisAlignment: MainAxisAlignment.spaceBetween,
                     children: [
                       Column(
                         crossAxisAlignment: CrossAxisAlignment.start,
                         children: [
                           Text("Recommended for you",style: TextStyle(
                               color: Colors.black,
                               fontSize: 16,
                               fontWeight: FontWeight.w600
                           ),),
                           SizedBox(
                             height: 2.h,
                           ),
                           Text("Most searched properties in Ahm.",style: TextStyle(
                               color: Colors.grey,
                               fontSize: 14,
                               fontWeight: FontWeight.w400
                           ),)
                         ],
                       ),
                       Text("See All",style: TextStyle(
                           color: Colors.black,fontSize: 14,fontWeight: FontWeight.w800
                       ),)
                     ],
                   ),
                 ),
                 SizedBox(
                   height: 20.h,
                 ),
                 Padding(
                   padding: const EdgeInsets.symmetric(horizontal: 20),
                   child: SingleChildScrollView(
                     scrollDirection: Axis.horizontal,
                     child: Row(
                       children: [
                         Stack(
                           children: [
                             ClipRRect(
                               borderRadius: BorderRadius.circular(10),
                               child: Image.asset(
                                 'assets/images/Building/building1.jpg',
                                 height: 270.0,
                                 width: 200.0,
                                 fit: BoxFit.fill,
                               ),
                             ),
                             Positioned(
                               top: 190,
                               child: Container(
                                 decoration: BoxDecoration(
                                   border: Border.all(width: 1,color: Colors.white),
                                   borderRadius: BorderRadius.circular(5),
                                   color: AppColor.themecolor,
                                 ),

                                 child: Padding(
                                   padding: const EdgeInsets.only(left: 5,top: 5,right: 5),
                                   child: Column(
                                     crossAxisAlignment: CrossAxisAlignment.start,
                                     children: [
                                       Text("HH Pravesh",style: TextStyle(
                                           color: Colors.white,fontWeight: FontWeight.w600,fontSize: 10
                                       ),),
                                       Text("By HH Builders",style: TextStyle(
                                           color: Colors.white,fontWeight: FontWeight.w400,fontSize: 8
                                       ),),
                                       SizedBox(
                                         height: 5.h,
                                       ),
                                       Text("₹ 35.62L - 1.25CR",style: TextStyle(
                                           color: Colors.white,fontWeight: FontWeight.w600,fontSize: 10
                                       ),),
                                       Text("2-3-4 BHK Apartments",style: TextStyle(
                                           color: Colors.white,fontWeight: FontWeight.w600,fontSize: 8
                                       ),),
                                       SizedBox(
                                         height: 5.h,
                                       ),
                                       Text("Ghatlodiya, Ahmedabad",style: TextStyle(
                                           color: Colors.white,fontWeight: FontWeight.w600,fontSize: 10
                                       ),),
                                     ],
                                   ),
                                 ),
                               ),
                             ),
                             Positioned(
                               top: 10,
                               left: 160,
                               child: Container(
                                   decoration: BoxDecoration(
                                     color: Colors.white,
                                     borderRadius: BorderRadius.circular(30),
                                   ),
                                   child: Padding(
                                     padding: const EdgeInsets.all(5),
                                     child: Icon(Icons.favorite,color: AppColor.themecolor,size: 20,),
                                   )),
                             ),


                             // Container(
                             //     height:200.h,
                             //     width:200.w,
                             //     decoration: BoxDecoration(
                             //       borderRadius: BorderRadius.circular(10),
                             //       border: Border.all(width: 1)
                             //     ),
                             //     child: Image.asset('assets/images/Building/building1.jpg',fit: BoxFit.fill,)),
                           ],
                         ),
                         SizedBox(
                           width: 10.w,
                         ),
                         Stack(
                           children: [
                             ClipRRect(
                               borderRadius: BorderRadius.circular(10),
                               child: Image.asset(
                                 'assets/images/Building/building2.jpg',
                                 height: 270.0,
                                 width: 200.0,
                                 fit: BoxFit.fill,
                               ),
                             ),
                             Positioned(
                               top: 190,
                               child: Container(
                                 decoration: BoxDecoration(
                                   border: Border.all(width: 1,color: Colors.white),
                                   borderRadius: BorderRadius.circular(5),
                                   color: AppColor.themecolor,
                                 ),

                                 child: Padding(
                                   padding: const EdgeInsets.only(left: 5,top: 5,right: 5),
                                   child: Column(
                                     crossAxisAlignment: CrossAxisAlignment.start,
                                     children: [
                                       Text("Parkview 2",style: TextStyle(
                                           color: Colors.white,fontWeight: FontWeight.w600,fontSize: 10
                                       ),),
                                       Text("By Shivalik Group",style: TextStyle(
                                           color: Colors.white,fontWeight: FontWeight.w400,fontSize: 8
                                       ),),
                                       SizedBox(
                                         height: 5.h,
                                       ),
                                       Text("₹ 58 Lac",style: TextStyle(
                                           color: Colors.white,fontWeight: FontWeight.w600,fontSize: 10
                                       ),),
                                       Text("3 BHK Apartments",style: TextStyle(
                                           color: Colors.white,fontWeight: FontWeight.w600,fontSize: 8
                                       ),),
                                       SizedBox(
                                         height: 5.h,
                                       ),
                                       Text("Shola, Ahmedabad",style: TextStyle(
                                           color: Colors.white,fontWeight: FontWeight.w600,fontSize: 10
                                       ),),
                                     ],
                                   ),
                                 ),
                               ),
                             ),
                             Positioned(
                               top: 10,
                               left: 160,
                               child: Container(
                                   decoration: BoxDecoration(
                                     color: Colors.white,
                                     borderRadius: BorderRadius.circular(30),
                                   ),
                                   child: Padding(
                                     padding: const EdgeInsets.all(5),
                                     child: Icon(Icons.favorite,color: AppColor.themecolor,size: 20,),
                                   )),
                             ),


                             // Container(
                             //     height:200.h,
                             //     width:200.w,
                             //     decoration: BoxDecoration(
                             //       borderRadius: BorderRadius.circular(10),
                             //       border: Border.all(width: 1)
                             //     ),
                             //     child: Image.asset('assets/images/Building/building1.jpg',fit: BoxFit.fill,)),
                           ],
                         ),
                         SizedBox(
                           width: 10.w,
                         ),
                       ],
                     ),
                   ),
                 ),
               ],
             ),
           ),

         ],
       ),
     ),

      bottomNavigationBar: buildMyNavBar(context)
    );

  }
  Container buildMyNavBar(BuildContext context) {
    return Container(
      height: 60.h,
      decoration: BoxDecoration(

        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(20),
          topRight: Radius.circular(20),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          Column(
            children: [
              IconButton(
                enableFeedback: false,
                onPressed: () {
                  setState(() {
                    pageIndex = 0;
                  });
                },
                icon: pageIndex == 0
                    ? const Icon(
                  Icons.home_filled,
                  color: AppColor.themecolor,
                  size: 35,
                )
                    : const Icon(
                  Icons.home_outlined,
                  color:AppColor.themecolor,
                  size: 35,
                ),
              ),
              Text("Home",style: TextStyle(
                color: AppColor.themecolor,fontWeight: FontWeight.w600
              ),)
            ],
          ),
          Column(
            children: [
              IconButton(
                enableFeedback: false,
                onPressed: () {
                  setState(() {
                    pageIndex = 1;
                  });
                },
                icon: pageIndex == 1
                    ? const Icon(
                  Icons.favorite,
                  color: AppColor.themecolor,
                  size: 35,
                )
                    : const Icon(
                  Icons.favorite_border,
                  color:AppColor.themecolor,
                  size: 35,
                ),
              ),
              Text("Favourite",style: TextStyle(
                  color: AppColor.themecolor,fontWeight: FontWeight.w600
              ),)
            ],
          ),
         Column(
           children: [
             IconButton(
               enableFeedback: false,
               onPressed: () {
                 setState(() {
                   pageIndex = 2;
                 });
               },
               icon: pageIndex == 2
                   ? const Icon(
                 Icons.access_time,
                 color: AppColor.themecolor,
                 size: 35,
               )
                   : const Icon(
                 Icons.access_time_filled_rounded,
                 color: AppColor.themecolor,
                 size: 35,
               ),
             ),
             Text("Activity",style: TextStyle(
                 color: AppColor.themecolor,fontWeight: FontWeight.w600
             ),)
           ],
         ),
          Column(
            children: [
              IconButton(
                enableFeedback: false,
                onPressed: () {
                  setState(() {
                    pageIndex = 3;
                  });
                },
                icon: pageIndex == 3
                    ? const Icon(
                  Icons.person,
                  color: AppColor.themecolor,
                  size: 35,
                )
                    : const Icon(
                  Icons.person_outline,
                  color: AppColor.themecolor,
                  size: 35,
                ),
              ),
              Text("Account",style: TextStyle(
                  color: AppColor.themecolor,fontWeight: FontWeight.w600
              ),)

            ],
          )

        ],
      ),
    );
  }
}
