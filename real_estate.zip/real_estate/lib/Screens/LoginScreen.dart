import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:real_estate/Constant/theme.dart';
import 'package:real_estate/Screens/DashboardScreen.dart';
import 'package:real_estate/Screens/ForgotPassword.dart';
import 'package:real_estate/Screens/LoginwithMobile.dart';
import 'package:real_estate/Screens/SignupScreen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  bool ishidden = true;
  final _scaffoldkey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Form(
            key: _scaffoldkey,
            child: Column(
              children: [
                SizedBox(
                  height: 70.h,
                ),
                Row(
                  children: [
                    Icon(
                      Icons.home_work_outlined,
                      size: 50,
                      color: AppColor.themecolor,
                    ),
                  ],
                ),
                SizedBox(
                  height: 10.h,
                ),
                Row(
                  children: [
                    Text(
                      "Welcome Back",
                      style: TextStyle(
                          color: Colors.black,
                          fontSize: 25,
                          fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
                SizedBox(
                  height: 10.h,
                ),
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        "Login to your account to accomplish your search for dream house.",
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 14,
                            fontWeight: FontWeight.w300),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 30.h,
                ),
                TextFormField(
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'This Field Is Required';
                    }

                    // using regular expression
                    if (!RegExp(r'\S+@\S+\.\S+').hasMatch(value)) {
                      return "Please Enter a Valid Email Address";
                    }

                    // the email is valid
                    return null;
                  },
                  decoration: InputDecoration(
                    hintText: "Your Email",
                      label: Text("Email",style: TextStyle(color: AppColor.themecolor),),
                      focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: AppColor.themecolor),
                          borderRadius: BorderRadius.circular(10)),
                      border: OutlineInputBorder(
                        borderSide: BorderSide(color: AppColor.themecolor),
                          borderRadius: BorderRadius.circular(10))),
                ),
                SizedBox(
                  height: 20.h,
                ),
                TextFormField(
                  obscureText: ishidden,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return "This Field Is Required";
                    }
                  },
                  decoration: InputDecoration(
                    hintText: "Enter Password",
                      label: Text("Password",style: TextStyle(color: AppColor.themecolor)),

                      suffixIcon: IconButton(
                          onPressed: () {
                            setState(() {
                              ishidden = !ishidden;
                            });
                          },
                          icon: ishidden == true
                              ? const Icon(Icons.visibility_off,
                                  size: 25, color: Color(0XFF132E81))
                              : const Icon(Icons.visibility,
                                  size: 25, color: Color(0XFF132E81))),
                      border: OutlineInputBorder(
                          borderSide: BorderSide(color: AppColor.themecolor),
                          borderRadius: BorderRadius.circular(10)),
                    focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: AppColor.themecolor),
                        borderRadius: BorderRadius.circular(10))
                  ),
                ),
                SizedBox(
                  height: 10.h,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    InkWell(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(builder: (context) => LoginwithMobile(),));
                      },
                      child: Text(
                        "Login with OTP",
                        style: TextStyle(
                            color: Colors.black, fontWeight: FontWeight.w600),
                      ),
                    ),
                    InkWell(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(builder: (context) => ForgotPassword(),));
                      },
                      child: Text(
                        "Forgot Password?",
                        style: TextStyle(
                            color: Colors.black, fontWeight: FontWeight.w600),
                      ),
                    )
                  ],
                ),
                SizedBox(
                  height: 20.h,
                ),
                InkWell(
                  onTap: (){
                    // if(_scaffoldkey.currentState!.validate()){
                    //   Fluttertoast.showToast(
                    //       msg:
                    //       "LOGIN SUCCESSFULY",
                    //       backgroundColor: AppColor.themecolor,
                    //       textColor: Colors.white,
                    //       gravity: ToastGravity.CENTER,
                    //       timeInSecForIosWeb: 50,
                    //       toastLength: Toast.LENGTH_SHORT);
                    // }else {
                    //   Fluttertoast.showToast(
                    //       msg:
                    //       "ALL FIELD ARE REQUIRED",
                    //       backgroundColor: AppColor.themecolor,
                    //       textColor: Colors.white,
                    //       gravity: ToastGravity.CENTER,
                    //       timeInSecForIosWeb: 50,
                    //       toastLength: Toast.LENGTH_SHORT);
                    // }
                    Navigator.push(context, MaterialPageRoute(builder: (context) => DashboardScreen(),));
                  },
                  child: Container(
                    height: 50.h,
                    width: double.infinity,
                    decoration: BoxDecoration(
                        color: AppColor.themecolor,
                        borderRadius: BorderRadius.circular(10)),
                    child: Center(
                      child: Text(
                        "LOGIN",
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 17.sp,
                            fontWeight: FontWeight.w800),
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: 20.h,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      height: 1.h,
                      width: 70.w,
                      color: Colors.grey,
                    ),
                    SizedBox(
                      width: 5.w,
                    ),
                    Text(
                      "OR",
                      style: TextStyle(color: Colors.black, fontSize: 17),
                    ),
                    SizedBox(
                      width: 5.w,
                    ),
                    Container(
                      height: 1.h,
                      width: 70.w,
                      color: Colors.grey,
                    ),
                  ],
                ),
                SizedBox(
                  height: 20.h,
                ),
                Container(
                  height: 50.h,
                  width: double.infinity,
                  decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey),
                      borderRadius: BorderRadius.circular(10)),
                  child: Row(
                    children: [
                      SizedBox(
                        width: 30.w,
                      ),
                      Image.asset('assets/images/google.jpg',scale: 7,),
                      SizedBox(
                        width: 30.w,
                      ),
                      Text("Sign in with Google",style: TextStyle(color: Colors.black,fontSize: 16,fontWeight: FontWeight.w400),)

                    ],
                  ),
                ),
                SizedBox(
                  height: 10.h,
                ),
                Container(
                  height: 50.h,
                  width: double.infinity,
                  decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey),
                      borderRadius: BorderRadius.circular(10)),
                  child: Row(
                    children: [
                      SizedBox(
                        width: 28.w,
                      ),
                      Image.asset('assets/images/facebook.jpg',scale: 7,),
                      SizedBox(
                        width: 30.w,
                      ),
                      Text("Sign in with Facebook",style: TextStyle(color: Colors.black,fontSize: 16,fontWeight: FontWeight.w400),)

                    ],
                  ),
                ),
                SizedBox(
                  height: 30.h,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      "Don't have an account ? ",
                      style: TextStyle(
                          color: Colors.black,
                          fontSize: 14,
                          fontWeight: FontWeight.w300),
                    ),
                    InkWell(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(builder: (context) => SignupScreen(),));
                      },
                      child: Text("SIGNUP",style: TextStyle(
                        color: AppColor.themecolor,fontSize: 14,fontWeight: FontWeight.w600
                      ),),
                    )
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
